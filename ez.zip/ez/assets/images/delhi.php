<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
</html>
<body>

<div class="container"> 
    <div class="row">
        <div class="col-md-6 std-img">
           <img class='height250' src="3.Delhi/Sub places of delhi/akshardam temple.jpg" class="img-fluid std-img "><p><button>Akshardam Temple</button></p><br>
        </div>
        <div class="col-md-6 std-img ">
            <img class='height250' src="3.Delhi/Sub places of delhi/India gate.jpg" class="img-fluid std-img"><p><button>India Gate</button></p><br>
        </div>
        <div class="col-md-6 std-img" class="img-fluid std-img">
            <img class='height250' src="4.kolkatta/sub places of kolkatta/st pauls cathedral.jpg"><p><button>Lotus Temple</button></p>
        </div>
        <div class="col-md-6 std-img">
            <img class='height250' src="4.kolkatta/sub places of kolkatta/VICTORIA-MEMORIAL.jpg" class="img-fluid std-img "><p><button><a href="delhi1/qutub.html"> Qutub Minar</a> </button></p><br>
        </div>
       
        </div>
    </div>
</div>
</body>
</html>