<html lang="en" >
<head>
<link href="stylesheet.css" rel="stylesheet">
<meta charseet="UTF-8">
<title> Payment</title>
</head>
<body>

    <div class="wrapper">
        <div class="checkout_wrapper">
            <div class="product_info">
                <img src="Ez_Travels_LOGO.jpg" alt="">
                <div class="content">
                    <h3>EzTravels <br> Best service</h3>
                    <P>500</P>
                </div>
            </div>

           <div class="checkout_form">
               <p>Payment Section</p>
                <div class="details">
                    <div class="section">
                        <input type="text" placeholder="Card Number">
                    </div>
                    <div class="section">
                        <input type="text" placeholder="Card Holder Number">
                    </div>
                    <div class="section last_section">
                        <input type="text" placeholder="Expire Date">
                    </div>
                    <div class="item">
                        <input type="text" placeholder="CVV">


                    </div>
                    
                </div>
                    <div class="btn">
                        <a href="#">Pay</a>
                    </div>

           </div>

        </div>
    </div>
</div>
</body>

</html>