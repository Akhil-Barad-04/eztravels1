<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// login register routes
$route['register'] = 'Welcome/index';
$route['login'] = 'Welcome/login';
$route['home'] = 'Welcome/home';
$route['logout'] = 'Welcome/logout';

//hyderabad
$route['main']='Welcome/main';
$route['hyd']='Welcome/hyd';
$route['mumbai']='Welcome/mumbai';
$route['kolkata']='Welcome/kolkata';
$route['delhi']='Welcome/delhi';
$route['test'] = "TestController/index";

//hyderabad
$route['birla'] = "Welcome/birla";
$route['hussain'] ='Welcome/hussain';
$route['golkonda'] = "Welcome/golkonda";
$route['charminar'] = 'Welcome/charminar';

//Mumbai
$route['shivaji'] = 'Welcome/shivaji';
$route['gate_way_of_india'] = 'Welcome/gate_way_of_india';
$route['marine_drive'] = 'Welcome/marine_drive';
$route['mountmary_church'] = 'Welcome/mountmary_church';


//delhi
$route['Akshardam_Temple'] = 'Welcome/Akshardam_Temple';
$route['India_Gate'] = 'Welcome/India_Gate';
$route['Lotus_Temple'] = 'Welcome/Lotus_Temple';
$route['Qutub_Minar'] = 'Welcome/Qutub_Minar';



//kolkatta

$route['Belur_Math'] = 'Welcome/Belur_Math';
$route['Howrah_Bridge'] = 'Welcome/Howrah_Bridge';
$route['St_Pauls_Cathedral'] = 'Welcome/St_Pauls_Cathedral';
$route['Victoria_Memorial'] = 'Welcome/Victoria_Memorial';



//Payment
$route['payment'] = 'Welcome/payment';

//about us

$route['aboutus'] = 'Welcome/aboutus';

//knowmore
$route['know_more'] = 'Welcome/know_more';

//thank_you
$route['thank_you'] = 'Welcome/thank_you';
