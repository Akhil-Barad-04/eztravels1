<?php
 /**
  *
  */
 class LoginModel extends CI_Model{

   public function checkCred($email, $password){
     $query = $this->db->query("select Email, Password from user_details where Email='$email' and Password='$password'");
     $row = $query->result_array();
     if(count($row) > 0){
       return true;
     } else{
       return false;
     }
   }
 }


?>
