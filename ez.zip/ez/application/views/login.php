<?php $this->load->view('layout/header'); ?>
<style>
.hello{
background: url(assets/images/backg.jpeg) no-repeat center center ;
background-size:cover ;
}
</style>
<body class="hello">
        <div class="form">
            <form class="login-form" action="" method="post" >
                <h2><i><b>Login</b></i></h2>
                <div class="icons">
                  <a href="#"><i class="fab fa-google"></i></a>
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>


                </div>

                <input  type="text" name="email" value="" placeholder="Email" required>
                <input  type="password" name="password" value="" placeholder="Password" required>
                <button type="submit" name="button">Login</button>
                <p class="options">Not Registered? <tab><a href="<?php echo base_url('register'); ?>">Create an Account </a></p></tab>



            </form>
        </div>
</body>
<?php $this->load->view('layout/footer'); ?>
