<section>
    
    <div class="container-field">
    <div class="text-center bg-dark text-light pt-auto"><h1>Services We Provide</h1></div>
    <hr class="w-25 mx-auto pt-5">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-12">
    
    
        <div class="card text-center" style="width:400px">
        <img class="card-img-top" src="images/hyderabad.webp" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Hyderabad</h4>
          <h6 class="card-text">click the profile to know about the services in hyderabad</h6>
          <a href="#" class="btn btn-primary">See Profile</a>
        </div>
        </div>
      </div>
          <div class="col-lg-4 col-md-4 col-12">
      <div class="card" style="width:400px">
        <img class="card-img-top" src="images/Kolkata.jpg" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Kolkata</h4>
          <h6 class="card-text">click the profile to know about the services in kolkata</h6>
          <a href="#" class="btn btn-primary">See Profile</a>
        </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12">
      <div class="card" style="width:400px">
        <img class="card-img-top" src="images/mumbai.jpg" alt="Card image">
        <div class="card-body">
          <h4 class="card-title">Mumbai</h4>
          <h6 class="card-text">click the profile to know about the services in Mumbai</h6>
          <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> Start Payment</a>
        </div>
        </div>
      </div>
    