<?php $this->load->view('layout/header'); ?>


        <div class="form ">
            <form class="login-form text-center" action="register"  method="post">

                <h2><i><b>Sign Up</b></i></h2>
                <div class="icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>


                </div>

                <input  type="email" name="email" placeholder="Email" required>


                <input  type="password" name="password" placeholder="Password" required>
                <input  type="number" name="phone" placeholder="Contact" required>
                <button type="submit" name="button">Sign Up</button>
                <p class="options"><a href="<?php echo base_url('login'); ?>">Have an Account </a></p>



            </form>
        </div>


<?php $this->load->view('layout/footer'); ?>
