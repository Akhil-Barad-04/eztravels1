<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> St.Pauls </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/hello.jpg') ?>">
</div>

<p><i><b>St. Paul's Cathedral is a CNI (Church of North India) Cathedral of Anglican background in Kolkata, West Bengal, India, noted for its Gothic architecture. It is the seat of the Diocese of Calcutta. The cornerstone was laid in 1839; the building was completed in 1847.[1] It is said to be the largest cathedral in Kolkata and the first Episcopal Church in Asia.It was also the first cathedral built in the overseas territory of the British Empire. The edifice stands on Cathedral Road on the "island of attractions" to provide for more space for the growing population of the European community in Calcutta in the 1800s.

Following the 1897 earthquake and the subsequent massive earthquake of 1934, when Calcutta suffered substantial damage, the cathedral was reconstructed to a revised design. The architectural design of the cathedral is "Indo-Gothic", a Gothic architectural style designed to meet the climatic conditions of India. The cathedral complex has a library, situated over the western porch, and a display of Plastic art forms and memorabilia.



</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
