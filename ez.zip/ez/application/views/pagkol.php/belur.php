<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Belur Math </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/400px-Ramakrishna_Belur_Math,.jpg') ?>">
</div>

<p><i><b>Ramakrishna Math is the administrative legal organization of the Ramakrishna Order,considered part of the Hindu reform movements. It was set up by sanyasin disciples of Ramakrishna pramhansa headed by Swami Vivekananda at Baranagar Math in Baranagar, a place near Calcutta (now Kolkata), in 1886. India. The headquarters of Ramakrishna Math and its twin organisation, Ramakrishna Mission is at Belur Math (in West Bengal, India).

Although Ramakrishna Math and Ramakrishna Mission are legally and financially separate, they are closely inter-related in several other ways and are to be regarded as twin organizations. All branch centres of Ramakrishna Math come under the administrative control of the Board of Trustees, whereas all branch centres of Ramakrishna Mission come under the administrative control of the Governing Body of Ramakrishna Mission.

</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
