<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black
  ;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Charminar </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/440px-Charminar-Pride_of_Hyderabad.jpg') ?>">
</div>

<p><i><b>The Charminar (lit. "four minarets"), constructed in 1591, is a monument and mosque located in Hyderabad, Telangana, India.<br> The landmark has become known globally as a symbol of Hyderabad and is listed among the most recognized structures in India.<br> It has also been officially incorporated as the Emblem of Telangana for the state of Telangana.<br>The Charminar's long history includes the existence of a mosque on its top floor for more than 400 years.<br> While both historically and religiously significant, it is also known for its popular and busy local markets surrounding the structure, and has become one of the most frequented tourist attractions in Hyderabad.<br> Charminar is also a site of numerous festival celebrations, such as Eid-ul-adha and Eid al-Fitr.

</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
