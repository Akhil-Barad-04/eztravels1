<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Qutub Minar </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/400px-Qutb_Minar_2011.jpg') ?>">
</div>

<p><i><b>The Qutb Minar, also spelled as Qutub Minar and Qutab Minar, is a minaret and "victory tower" that forms part of the Qutb complex, a UNESCO World Heritage Site in the Mehrauli area of Delhi, India. Qutb Minar was 73-metres (239.5 feet) tall before the final, fifth section was added after 1369. The tower tapers, and has a 14.3 metres (47 feet) base diameter, reducing to 2.7 metres (9 feet) at the top of the peak. It contains a spiral staircase of 379 steps.

Its closest comparator is the 62-metre all-brick Minaret of Jam in Afghanistan, of c.1190, a decade or so before the probable start of the Delhi tower. The surfaces of both are elaborately decorated with inscriptions and geometric patterns; in Delhi the shaft is fluted with "superb stalactite bracketing under the balconies" at the top of each stage. In general minarets were slow to be used in India, and are often detached from the main mosque where they exist.
</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
