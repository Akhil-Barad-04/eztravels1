<html>

<style>
h1{

  color:black;

}


body{

  background:url("assets/images/pink.jpeg");
}


p{
  color:black;
}

.hello{
  border-radius:35px;
}

</style>


<body>


<h1> Lotus Temple </h1>
<div class="hello">

<img src= "<?php echo base_url('assets/images/inside/480px-LotusDelhi.jpg') ?>">
</div>

<p><i><b>The Lotus Temple, located in Delhi, India, is a Baháʼí House of Worship that was dedicated in December 1986.Notable for its flowerlike shape, it has become a prominent attraction in the city. Like all Baháʼí Houses of Worship, the Lotus Temple is open to all, regardless of religion or any other qualification. The building is composed of 27 free-standing marble-clad "petals" arranged in clusters of three to form nine sides, with nine doors opening onto a central hall with a height of slightly over 34.27 metres and a capacity of 2,500 people. The Lotus Temple has won numerous architectural awards and has been featured in many newspaper and magazine articles. A 2001 CNN report referred to it as the most visited building in the world.
</b></i></p>

<br>
<br>

<button ><a href="payment"> Payment </button>


</body>

</html>
