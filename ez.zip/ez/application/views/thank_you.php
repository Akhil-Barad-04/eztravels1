<html>

<style>
.body{
background: url(assets/images/thankyou.jpeg);
background-size:cover ;
}
</style>
<body>
<br>
<br>

<br>
<br>


</body>
</html>
